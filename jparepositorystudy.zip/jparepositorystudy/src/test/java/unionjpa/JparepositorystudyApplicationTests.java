package unionjpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JparepositorystudyApplicationTests {

	@Test
	void contextLoads() {
	}

}
